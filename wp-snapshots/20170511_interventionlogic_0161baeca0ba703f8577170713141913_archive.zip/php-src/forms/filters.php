
<?php
    //print_r($user_id);

    echo "<fieldset class='invest-filters'>
    
    <div class='info-div'><i class='fa fa-info' aria-hidden='true'></i></div>

    <div class='notes hide'>
        <p class='notes-title'>Investment Priority</p>

        <i class='fa fa-times' aria-hidden='true'></i>

        <p class='notes-body'>
            In this section, you can select your filters, in order to 
            specify the Thematic Objective and the Investment Priority, 
            corresponding to the intervention logic diagram that you 
            want to implement.
        </p>
    </div>

    <legend>Investment Priority</legend>";
	
    $all_prios = exec_select($conn, "SELECT * FROM eu_prio");
    
    $user_prios = exec_select($conn, "SELECT inv_id FROM user_prio WHERE user_id = $user_id");
    $user_prios = json_encode($user_prios);
    
//    print_r($user_id);
    
    $all_objectives = exec_select($conn, "SELECT * FROM objective");
    $all_objectives = json_encode($all_objectives);
    
    $all_investments = exec_select($conn, "SELECT * FROM inv_prio");
    $all_investments = json_encode($all_investments);
    
    echo "<div class='choose-eu-pr'>";
    
    $i = 0;
    $colors = ['one','two','three'];
    
    if ($prio) {
        $res = exec_select($conn, "SELECT ep.id FROM eu_prio ep JOIN objective obj ON ep.id = obj.eu_id JOIN inv_prio ip ON ip.obj_id = obj.id JOIN user_prio up ON up.inv_id = ip.id WHERE up.up_id = $prio");
        $eu_prio = $res[0]['id'];
        
        $res = exec_select($conn, "SELECT obj.id FROM objective obj JOIN inv_prio ip ON ip.obj_id = obj.id JOIN user_prio up ON up.inv_id = ip.id WHERE up.up_id = $prio");
        $obj = $res[0]['id'];
        
        $res = exec_select($conn, "SELECT inv_id FROM user_prio WHERE up_id = $prio");
        $inv = $res[0]['inv_id'];
    }
    
    $eu_priority = ($prio) ? $eu_prio : 1;
    $objective = ($prio) ? $obj : 'TO1';
    
    foreach ($all_prios as $val) {
        $id = $val['id'];
        $description = $val['description'];
        $checked = ($prio) ? (($eu_prio == $id) ? 'checked' : '') : ($i==0 ? 'checked' : '');
        
        $color=$colors[$i];
        echo "<input id='$id' type='checkbox' class='hide eu_pr' name='eu_pr' value='$id' onchange='return setPriority({objectives: $all_objectives, investments: $all_investments, prio:this.value });' $checked>
        <a href='#'><label id='$color' class='eu-rect' for='$id'><span>$description</span></label></a>";
        
        $i++;
    }
    
    echo "<button class='priorities-btn'  onclick='return openPopup"
    . "({ url: \"priorities\", name:\"priorities\", height:\"large\" })' >"
            . "Investment Priorities <i class='fa fa-list-alt' aria-hidden='true'></i>"
            . "</button>";
    
    echo "</div>";
    
    $prio_objectives = exec_select($conn, "SELECT * FROM objective WHERE eu_id=$eu_priority ORDER BY id");
    
    echo "<div class='choose-item'>";
    echo "<p>Choose the thematic objective: </p>";
        echo "<select id ='objective' class='chosen-select' data-placeholder='Choose objective' name='objective' onchange='return setObjective({investments: $all_investments, objective:this.value });' required>";
            foreach($prio_objectives as $val) {
                $id = $val['id'];
                $description = $val['description'];
                $checked = ($prio && $id == $objective) ? 'selected' : '';
                echo "<option value='$id' $checked>$id - $description</option>";
            }
        echo "</select>";
    echo "</div>";
    
    $investments = exec_select($conn, "SELECT * FROM inv_prio WHERE obj_id='$objective' ORDER BY id");
    
    echo "<div class='choose-item'>";
    echo "<p>Choose the investment priority: </p>";
        echo "<select id ='investment' class='chosen-select' data-placeholder='investment priority ..' name='inv_pr'  onchange='return prioExists({prio: this.value, user_prios:$user_prios });' required>";
            $checked_init = (isset($_POST['investment'])) ? '' : 'selected';
            foreach($investments as $val) {
                $id = $val['id'];
                $description = $val['description'];
                $checked = ($prio && $inv==$id) ? 'selected' : '';
                echo "<option value='$id' $checked>$id - $description</option>";
            }
        echo "</select>";
    echo "</div>";
    
    echo "<input id='previousprio' class='hide' />";
    
    echo "</fieldset>";