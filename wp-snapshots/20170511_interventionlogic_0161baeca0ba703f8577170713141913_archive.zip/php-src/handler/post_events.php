<?php


if($_SERVER["REQUEST_METHOD"] == "POST" && (isset($_POST['new_prio']) || $_POST['new_pressed'] == 1)) {
    // test saved
    $user_id=1;
    
    load_prio($conn,$user_id);
    
}

if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save-prio'])) {
    $prio = $_POST['inv_pr'];
    $prio_id = save_prio($conn,$user_id,$prio);

    if($prio_id > 0) {
        $prio_saved = 1;
    }

    load_prio($conn,$user_id,$prio_id);
}

if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user-prio'])) {
    $prio_id = $_POST['user-prio'];
    
    load_prio($conn,$user_id,$prio_id);
}
    
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['export_report'])) {
    $prio = $_POST['inv_pr'];
    
    $prio_id = save_prio($conn,$user_id,$prio);

    load_prio($conn,$user_id,$prio_id);

    define('UPLOAD_DIR', 'files/');

    $name = $prio_id . '.png';
    $img_data = $_POST['tot_uni'];
    $file = UPLOAD_DIR . $name;

    $img = str_replace('data:image/png;base64,', '', $img_data);
    $data = base64_decode($img);
    $success = file_put_contents($file, $data);

    echo "<div class='report-container hide' id='report-container'>";

    echo "<p style='font-weight:bold'>Investment Priority:</p>";
    $eu_pr = $_POST['eu_pr'];
    echo "<p><span style='text-decoration:underline'>Eu priority:</span> $eu_pr</p>";
    $objective = $_POST['objective'];
    echo "<p><span style='text-decoration:underline'>Thematic objective:</span> $objective</p>";
    $investment = $_POST['inv_pr'];
    echo "<p><span style='text-decoration:underline'>Investement priority:</span> $investment</p>";

    echo "<p style='font-weight:bold'>Priority Contents:</p>";
    if ($success) {
        $src = 'files/' . $name;
        echo "<img src='$src' width='450' height='700'>";
    }

    echo "<p style='font-weight:bold'>Intervention Logic Description:</p>";
    $quest_1 = $_POST['quest_1'];
    echo "<p style='font-style:italic'>1. How is the context of your region related to the specific Investment Priority?</p>";
    echo "<p class='description'>$quest_1</p>";
    $quest_2 = $_POST['quest_2'];
    echo "<p style='font-style:italic'>2. In which ways the shared vision is related to the described regional context?</p>";
    echo "<p class='description'>$quest_2</p>";
    $quest_3 = $_POST['quest_3'];
    echo "<p style='font-style:italic'>3. Please, describe the interconnection between the specified priorities and the shared regional vision.</p>";
    echo "<p class='description'>$quest_3</p>";
    $quest_4 = $_POST['quest_4'];
    echo "<p style='font-style:italic'>4. In which ways the selected actions contribute to the accomplishment of the reginal priorities, related to this Investment Priority?</p>";
    echo "<p class='description'>$quest_4</p>";
    $quest_5 = $_POST['quest_5'];
    echo "<p style='font-style:italic'>5. How is the context of your region related to the specific Investment Priority?</p>";
    echo "<p class='description'>$quest_5</p>";
    $quest_6 = $_POST['quest_6'];
    echo "<p style='font-style:italic'>6. Please, give a short description of the policy mix related to the specific Investment Priority.</p>";
    echo "<p class='description'>$quest_6</p>";
    $quest_7 = $_POST['quest_7'];
    echo "<p style='font-style:italic'>7. Please, describe the rationale for choosing the specific output indicators, as well as the ways in which they are related to result indicators.</p>";
    echo "<p class='description'>$quest_7</p>";
    echo "</div>";


    ?>    
        <script type="text/javascript">
            $("#report-container").wordExport();
        </script>
    <?php
    
    print_r("UPDATE user_prio SET has_report=1 WHERE user_id = $user_id AND inv_id = '$prio_id'");
    
    exec_upd($conn, "UPDATE user_prio SET has_report=1 WHERE up_id = $prio_id");
}