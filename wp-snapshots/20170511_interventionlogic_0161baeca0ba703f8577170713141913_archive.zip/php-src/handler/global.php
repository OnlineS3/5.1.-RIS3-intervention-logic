<?php

$tips = array();

$tips[0] = 'In this section, you can add the main outcomes from the Analysis of '
        . 'the Context phase, which are related to the specific Priority Axis. '
        . 'These may include results coming from the mapping of the regional assets, '
        . 'research and infrastructure mapping, clusters incubators and innovation '
        . 'ecosystem mapping, as well as benchmarking.';

$tips[1] = 'In the Vision section, information related to results coming from '
        . 'Shared Vision/Strategy formulation and Priority setting phases should '
        . 'be added on the diagram. The four sub-sections included here, specifically '
        . 'refer to: scenario building and foresight exercises, EDP, extroversion and '
        . 'related variety analysis. For each one of them the user can add the most '
        . 'important outcomes that are related to the specific Priority Axis.';

$tips[2] = 'In the Vision section, information related to results coming from '
        . 'Shared Vision/Strategy formulation and Priority setting phases should '
        . 'be added on the diagram. The four sub-sections included here, '
        . 'specifically refer to: scenario building and foresight exercises, EDP, '
        . 'extroversion and related variety analysis. For each one of them the '
        . 'user can add Priority Axis.';

$tips[3] = 'In the Vision section, information related to results coming from '
        . 'Shared Vision/Strategy formulation and Priority setting phases should '
        . 'be added on the diagram. The four sub-sections included here, specifically '
        . 'refer to: scenario building and foresight exercises, EDP, extroversion '
        . 'and related variety analysis. For each one of them the user can add '
        . 'the most important outcomes that are related to the specific Priority Axis.';
