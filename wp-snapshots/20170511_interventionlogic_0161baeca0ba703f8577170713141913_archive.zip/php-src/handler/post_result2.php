<?php

include 'php-src/onlineS3/db_connector/exec_sql.php';
    
$conn = conn_db();
$user_id = 1;

save_prio($conn,$user_id);