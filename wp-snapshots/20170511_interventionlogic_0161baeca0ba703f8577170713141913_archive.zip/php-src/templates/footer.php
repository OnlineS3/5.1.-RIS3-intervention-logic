<footer id='site-footer'>

    <div id="footer-links">
        <ul>
            <li><a href='http://www.onlines3.eu/' target="_blank">Online S3 Project</a></li>
            <li class="active"><a href="#">Applications</a></li>
            
            <li>
                <a href='#' class="beta"/>Toolbox</a>
            </li>
            
            <li>
                <a href='#' class="beta"/>Analytics</a>
            </li>
            
            <li>
                <a href='#' class="beta"/>Support</a>
            </li>
            
            <li><a href='http://www.onlines3.eu/contact/' target="_blank">Contact</a></li>
        </ul>
        <div id='copyright'>
            <img src="images/logo.png" width="30" alt="online logo">
            <p>Copyright &copy; 2016-2017 OnlineS3 Project</p>
        </div>
    </div>

    <div id="european">
        <img src="images/eu_logo.png" width="85" alt="Co-funded by the European Union">

        <p>
            Funded by the Horizon 2020 Framework Programme of the European Union.
        </p>
    </div>
	
</footer>