
<div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
<div class="notes hide">
    <p class="notes-title">Vision statement and Strategic objectives</p>

    <i class="fa fa-times" aria-hidden="true"></i>

    <p class='notes-body'>
        <?php echo $tips[$index]; ?>
    </p>
</div>