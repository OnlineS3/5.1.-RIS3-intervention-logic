

<aside id='sidebar' class='base-sidebar <?php echo $about_hide ?>'>

<button class="guide" onclick='return openPopup({ url: "pdf/5.1 Intervention Logic_full users guide.pdf" });'> Download Guide <i class="fa fa-file-pdf-o" aria-hidden="true"></i></button>
		
<div></div>

<a id="tool-btn" class='a-button' href="#"> Access to application  <img src="images/access-icon.png" width="20"></button>

</aside>