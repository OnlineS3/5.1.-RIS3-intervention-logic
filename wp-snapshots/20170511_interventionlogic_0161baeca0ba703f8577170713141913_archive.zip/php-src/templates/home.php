<?php

//    phpinfo();
    include 'php-src/templates/header.php';
   
    $home = 'http://' . $_SERVER['SERVER_NAME'] . '/interlogic/home';

    echo "<form action='$home' method='post' id='logic-form'>";
    
    $about_hide = $_SERVER["REQUEST_METHOD"] == "POST" ? 'hide' : '';
    
    echo "<div class='interlogic'>";
    echo "<div id='about' class='section-page $about_hide plain'>";
    include 'php-src/templates/about.php';
    echo "</div>";
    
    echo "<div id='docs' class='section-page hide'>";
    include 'php-src/templates/docs.html';
    echo "</div>";

    echo "<div id='guide' class='section-page hide plain'>";
    include 'php-src/templates/guide.php';
    echo "</div>";
    
    $tool_hide = $_SERVER["REQUEST_METHOD"] == "POST" ? '' : 'hide';
    
    echo "<div id='tool' class='tool-page section-page $tool_hide'>";
    include 'php-src/templates/tool.php';
    echo "</div>";
    
    echo "</div>";
    // include header and categories
    // include 'php-src/templates/menu.php';
    
//    include 'prio_menu.php';
    include 'prio_menu.php';
    include 'sidebar.php';
    echo "</div>";
    
    
    
    echo "</form>";
    
    include 'php-src/templates/footer.php';
    
?>