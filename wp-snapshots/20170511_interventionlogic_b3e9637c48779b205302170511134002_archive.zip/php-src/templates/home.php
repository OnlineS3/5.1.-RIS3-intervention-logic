<?php

//    phpinfo();
    
    echo "<div class='interlogic'>";
    
    $about_hide = $_SERVER["REQUEST_METHOD"] == "POST" ? 'hide' : '';
    
    echo "<div id='about' class='section-page $about_hide'>";
    include 'php-src/templates/about.php';
    echo "</div>";

    echo "<div id='guide' class='section-page hide'>";
    include 'php-src/templates/use_cases.php';
    echo "</div>";
    
    $tool_hide = $_SERVER["REQUEST_METHOD"] == "POST" ? '' : 'hide';
    
    echo "<div id='tool' class='tool-page section-page $tool_hide'>";
    include 'php-src/templates/tool.php';
    echo "</div>";
    
    echo "</div>";
    // include header and categories
//    include 'php-src/templates/menu.php';
    
    echo "</div>";
    
    include 'php-src/templates/header.php';
    
    include 'php-src/templates/footer.php';
    
    
?>