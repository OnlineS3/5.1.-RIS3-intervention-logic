<?php 

include 'php-src/onlineS3/db_connector/connection.php';
include 'php-src/onlineS3/db_connector/exec_sql.php';
$conn = conn_db();

echo "<h2>Intervention Logic</h2>";

include "php-src/forms/filters.php";
//include "tabs.php";

echo "<fieldset class='logic-template'>";

echo "<legend>Priority Contents</legend>";

$file_name='test.png';

echo "<div class='main-btn'>";
echo "<div class='tooltip-container'>";
echo "<button class='button btn-logic beta'>Save Priority<i class='fa fa-floppy-o' aria-hidden='true'></i></button>";
echo "<span class='tooltiptext arrow-left' style='left: 116px;top: -5px;'>Not available in beta version</span>";
echo "</div>";
echo "<button class='button btn-logic export-btn' onclick='return exportElem2png({ div_id: \"export\", filename: \"test.png\" });'>Export as Image <i class='fa fa-file-image-o' aria-hidden='true'></i></button>";
echo "</div>";
    
include "boxes.php";
include "export_template.html";
echo "</fieldset>";

include "description.php";




 ?>