
<form action="" method="post">
    
    <div class='layer one' id="layer-one">

	
        <div class="box parent">
            <input name="title" value="Context" class="box-title" type="text" disabled>
        </div>

        <div class='parent-container' id='cont-one'>
            <input class="hide-comments hide" name="hide-comments" type='text' />
            <div class="container">
                <div class="box new">
                    <button id='0_1' onclick='return newBox(this.id,"one");'>
                        <i class='fa fa-plus' aria-hidden='true'></i>
                    </button>
                </div>
            </div>
            
            <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
            
            <div class="notes hide">
                <p class="notes-title">Context</p>

                <i class="fa fa-times" aria-hidden="true"></i>

                <p class='notes-body'>
                    In this section, you can add the main outcomes from the Analysis of the 
                    Context phase, which are related to the specific Priority Axis. 
                    These may include results coming from the mapping of the regional assets, 
                    research and infrastructure mapping, clusters incubators and innovation 
                    ecosystem mapping, as well as benchmarking.
                </p>
            </div>
            
        </div>

    </div>

    <div class='layer two'>

        <div class="box parent">
            <input name="title" value="Vision Statement / Priority setting" class="box-title" type="text" disabled>
        </div>

        <div class="two-all-divs">
            <div class='parent-container' id='cont-two'>
                <input class="hide-comments hide" name="hide-comments" type='text' />
                <div class="container horizon right">
                    <div class='header-div'><p style='left: -12px;top: 26px;'>EDP</p></div>

                    <div class="box new">
                        <button id='1a_0' onclick='return newBox(this.id,"two");'>
                            <i class='fa fa-plus' aria-hidden='true'></i>
                        </button>
                    </div>
                </div>

                <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
                
                <div class="notes hide">
                    <p class="notes-title">Vision statement and Strategic objectives</p>

                    <i class="fa fa-times" aria-hidden="true"></i>

                    <p class='notes-body'>
                        In the Vision section, information related to results coming from 
                        Shared Vision/Strategy formulation and Priority setting phases should be 
                        added on the diagram. The four sub-sections included here, specifically 
                        refer to: scenario building and foresight exercises, EDP, extroversion 
                        and related variety analysis. For each one of them the user can add 
                        the most important outcomes that are related to the specific 
                        Priority Axis. 
                    </p>
                </div>
            </div>

            <div class='parent-container' id='cont-three'>
                <input class="hide-comments hide" name="hide-comments" type='text' />
                <div class="container horizon right">

                    <div class='header-div'><p style='left: -51px;top: 15px;'>Extroversion analysis</p></div>
                    <div class="box new">
                        <button id='1b_0' onclick='return newBox(this.id,"two");'>
                            <i class='fa fa-plus' aria-hidden='true'></i>
                        </button>
                    </div>
                </div>  

                <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
                
                <div class="notes hide">
                    <p class="notes-title">Vision statement and Strategic objectives</p>

                    <i class="fa fa-times" aria-hidden="true"></i>

                    <p class='notes-body'>
                        In the Vision section, information related to results coming from 
                        Shared Vision/Strategy formulation and Priority setting phases should be 
                        added on the diagram. The four sub-sections included here, specifically 
                        refer to: scenario building and foresight exercises, EDP, extroversion 
                        and related variety analysis. For each one of them the user can add 
                        the most important outcomes that are related to the specific 
                        Priority Axis. 
                    </p>
                </div>
            </div>

            <div class='parent-container' id='cont-four'>
                <input class="hide-comments hide" name="hide-comments" type='text' />
                <div class="container horizon right">
                    <div class='header-div'><p style='left: -30px;top: 17px;'>Related variety</p></div>

                    <div class="box new">
                        <button id='1c_0' onclick='return newBox(this.id,"two");'>
                            <i class='fa fa-plus' aria-hidden='true'></i>
                        </button>
                    </div>
                </div> 

                <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
                <div class="notes hide">
                    <p class="notes-title">Vision statement and Strategic objectives</p>

                    <i class="fa fa-times" aria-hidden="true"></i>

                    <p class='notes-body'>
                        In the Vision section, information related to results coming from 
                        Shared Vision/Strategy formulation and Priority setting phases should be 
                        added on the diagram. The four sub-sections included here, specifically 
                        refer to: scenario building and foresight exercises, EDP, extroversion 
                        and related variety analysis. For each one of them the user can add 
                        the most important outcomes that are related to the specific 
                        Priority Axis. 
                    </p>
                </div>
            </div>

            <div class='parent-container' id='cont-five'>
                <input class="hide-comments hide" name="hide-comments" type='text' />
                <div class="container horizon right">  
                    <div class='header-div'><p style='left: -38px;top: 24px;'>Foresight</p></div>

                    <div class="box new">
                        <button id='1d_0' onclick='return newBox(this.id,"two");'>
                            <i class='fa fa-plus' aria-hidden='true'></i>
                        </button>
                    </div>
                </div>
                
                <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>

                <div class="notes hide">
                    <p class="notes-title">Vision statement and Strategic objectives</p>

                    <i class="fa fa-times" aria-hidden="true"></i>

                    <p class='notes-body'>
                        In the Vision section, information related to results coming from 
                        Shared Vision/Strategy formulation and Priority setting phases should be 
                        added on the diagram. The four sub-sections included here, specifically 
                        refer to: scenario building and foresight exercises, EDP, extroversion 
                        and related variety analysis. For each one of them the user can add 
                        the most important outcomes that are related to the specific 
                        Priority Axis. 
                    </p>
                </div>
            </div>
        </div>
        
        <!--<div id='arrow-2' class='first'><div class='up'></div><div class='down'></div></div>-->
        
    </div>
    
    <div class='layer three'>

        <div class="box parent">
            <input name="title" value="Policy mix" class="box-title" type="text" disabled>
        </div>

        <div class='parent-container' id='cont-six'>
            <input class="hide-comments hide" name="hide-comments" type='text' />
            <div class="container vertical alt">
                <p class='header'>Definition of actions</p>
                <div class="box new">
                    <button id="2a_0" onclick="return newBox(this.id,'three');">
                        <i class="fa fa-plus" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
            
            <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>

            <div class="notes hide move-one">
                <p class="notes-title">Definition of actions</p>
                <i class="fa fa-times" aria-hidden="true"></i>
                <p class='notes-body'>
                    The definition of actions includes the outcomes of action plan co-design, 
                    budgeting, administrative framework and innovation maps. The actions 
                    should be specified based on the need to achieve the Strategic 
                    Objectives, defined in the previous section.
                </p>
            </div>
        </div>

        <div class='parent-container' id='cont-seven'>
            <input class="hide-comments hide" name="hide-comments" type='text' />
            <div class="container vertical alt">
                <p class='header'>Action plan implementation</p>
                <div class="box new">
                    <button id="2b_0" onclick="return newBox(this.id,'three');">
                        <i class="fa fa-plus" aria-hidden="true"></i>
                    </button>
                </div>
            </div>

            <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
            
            <div class="notes hide move-two">
                <p class="notes-title">Action plan implementation</p>
                <i class="fa fa-times" aria-hidden="true"></i>
                <p class='notes-body'>
                    Categories of intervention refer to the specification of a 
                    selected number of types of intervention that will be 
                    included in the Smart Specialisation strategy, for the 
                    specific Priority Axis. These should be selected based on 
                    the Vision Statement and Strategic Objectives, that were 
                    described in the previous section. 
                </p>
            </div>
        </div>
        
        <img src="images/arrow1.png" id='arrow-1' width="37">
		
		<!--<div id='arrow-2' class='second'><div class='up'></div><div class='down'></div></div> -->
    </div>

    <div class='layer four'>
        <div class="box parent">
            <input name="title" value="Monitoring" class="box-title" type="text" disabled>
        </div>

        <div class='parent-container' id='cont-eight'>
            <input class="hide-comments hide" name="hide-comments" type='text' />
            <div class="container vertical alt">
                <p class='header'>Output indicators</p>
                <div class="box new">
                    <button id="3a_0" onclick="return newBox(this.id,'four');">
                        <i class="fa fa-plus" aria-hidden="true"></i>
                    </button>
                </div>
            </div>

            <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
            
            <div class="notes hide move-one">
                <p class="notes-title">Output indicators</p>

                <i class="fa fa-times" aria-hidden="true"></i>

                <p class='notes-body'>
                    Specification of the output indicators that are going to be used, 
                    based on the definition of actions for this Priority Axis.
                </p>
            </div>
        </div>

        <div class='parent-container' id='cont-nine'>
            <input class="hide-comments hide" name="hide-comments" type='text' />
            <div class="container vertical alt">
                <p class='header'>Result indicators</p>
                <div class="box new">
                    <button id="3b_0" onclick="return newBox(this.id,'four');">
                        <i class="fa fa-plus" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
            
            <div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
            
            <div class="notes hide move-two">
                <p class="notes-title">Result indicators</p>

                <i class="fa fa-times" aria-hidden="true"></i>

                <p class='notes-body'>
                    Specification of the result indicators that are going to be used, 
                    based on the Vision statement and the selected Strategic objectives 
                    for this Priority Axis.
                </p>
            </div>
        </div>

    </div>

        <?php include "box-popup.php"; ?>
    
    
</form>