
<aside id='sidebar' class='hide'>

    <button class="alt" id="download-guide"> Download Guide <i class="fa fa-file-pdf-o" aria-hidden="true"></i></button>

    <div></div>

    <button id="access-btn"> Access to application  <img src="../images/access-icon.png" width="20"></button>
		
</aside>