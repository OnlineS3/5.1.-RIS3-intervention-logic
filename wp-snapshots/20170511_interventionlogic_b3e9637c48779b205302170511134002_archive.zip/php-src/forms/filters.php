<?php
    echo "<fieldset class='invest-filters'>";
    
	echo "<div class='info-div'><i class='fa fa-info' aria-hidden='true'></i></div>";
	
	echo "<legend>Investment Priority</legend>";
	
    $all_prios = exec_select($conn, "SELECT * FROM eu_priority");
    
    $all_objectives = exec_select($conn, "SELECT * FROM objective");
    $all_objectives = json_encode($all_objectives);
    
    $all_investments = exec_select($conn, "SELECT * FROM inv_priority");
    $all_investments = json_encode($all_investments);
    
    echo "<div class='choose-eu-pr'>";
    
    $i = 0;
    $colors = ['one','two','three'];
    foreach ($all_prios as $val) {
        $id = $val['id'];
        $description = $val['description'];
        $checked = ($_POST['eu_pr']) ? (($_POST['eu_pr'] == $id) ? 'checked' : '') : ($i==0 ? 'checked' : '');
        
        $color=$colors[$i];
        echo "<input id='$id' type='checkbox' class='hide eu_pr' name='eu_pr' value='$id' onchange='return setPriority({objectives: $all_objectives, prio:this.value });' $checked>
        <a href='#'><label id='$color' class='eu-rect' for='$id'><span>$description</span></label></a>";
        
        $i++;
    }
    
    echo "<button class='priorities-btn'  onclick='return openPopup"
    . "({ url: \"http://localhost/interlogic/priorities\", name:\"priorities\", height:\"large\" })' >"
            . "Investment Priorities Index <i aria-hidden='true' "
            . "style='color: #f87b6c;font-size: 14px;margin-left: 4px;top: 2px;"
            . "position: relative;margin-top: -4px;' class='fa fa-list-alt'></i>"
            . "</button>";
    
    echo "</div>";
    
    $eu_priority = ($_POST['eu_pr']) ? $_POST['eu_pr'] : 1;
    $prio_objectives = exec_select($conn, "SELECT * FROM objective WHERE eu_id=$eu_priority ORDER BY id");
    
    echo "<div class='choose-item'>";
    echo "<p>Choose the thematic objective: </p>";
        echo "<select id ='objective' class='chosen-select' data-placeholder='Choose objective' name='objective[]' onchange='return setObjective({investments: $all_investments, objective:this.value });' required>";
            foreach($prio_objectives as $val) {
                $id = $val['id'];
                $description = $val['description'];
                $checked = (isset($_POST['objective']) and contains($prio_objectives, $id)) ? 'selected' : '';
                echo "<option value='$id'  $checked>$id - $description</option>";
            }
        echo "</select>";
    echo "</div>";
    
    $objective = ($_POST['objective']) ? $_POST['objective'] : 'TO1';
	
    $investments = exec_select($conn, "SELECT * FROM inv_priority WHERE obj_id='$objective' ORDER BY id");
    
    echo "<div class='choose-item'>";
    echo "<p>Choose the investment priority: </p>";
        echo "<select id ='investment' class='chosen-select' data-placeholder='investment priority ..' name='inv_pr[]' required>";
			 $checked_init = (isset($_POST['investment'])) ? '' : 'selected';
			 echo "<option value='0' $checked_init></option>";
            foreach($investments as $val) {
                $id = $val['id'];
                $description = $val['description'];
                $checked = (isset($_POST['investment']) and contains($investments, $id)) ? 'selected' : '';
                echo "<option value='$id' $checked>$id - $description</option>";
            }
        echo "</select>";
    echo "</div>";
    
    
    echo "</fieldset>";