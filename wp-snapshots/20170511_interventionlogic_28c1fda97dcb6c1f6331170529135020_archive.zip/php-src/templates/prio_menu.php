<?php 
    echo "<div class='r-sidebar $tool_hide' id='prio-bar'>
        <div class='cat-caption'>
            <p>My Priorities</p>
        </div>";
     
    $prios = exec_select($conn,"SELECT up_id, inv_id  FROM user_prio WHERE user_id = $user_id;");
    $home = 'http://' . $_SERVER['SERVER_NAME'] . '/interlogic/home';
    
    if ($prios) {
        foreach($prios as $prio) {
            $prio_id = $prio['up_id'];
            $prio = $prio['inv_id'];
            echo "<input id='up-$prio_id' class='hide choose-prio' type='checkbox' name='user-prio' value='$prio_id'>"; 
            echo "<label for='up-$prio_id'>$prio</label>"; 
        }
    }
    
    echo "<input type='submit' class='hide' value='Submit' id='show-prio'>";
    
    echo "</div>";
  
?>
