<?php 

    include 'php-src/onlineS3/db_connector/connection.php';
    include 'php-src/onlineS3/db_connector/exec_sql.php';
    include 'php-src/onlineS3/gen_fun/str_fun.php';
    include 'php-src/handler/main_func.php';
    include 'php-src/db_func/save_prio.php';
    $conn = conn_db();
    
    define('UPLOAD_DIR', 'files/');
    
    echo "<h2>Intervention Logic</h2>";
    
    echo "<div class='main-btn' style='border-bottom: none'>";
    echo "<input type='submit' class='button btn-logic export-btn' name='save-prio' value='Save Priority' id='save-prio'><i id='save-fa' class='fa fa-floppy-o' aria-hidden='true'></i>";
    
    echo "<input type='submit' class='button btn-logic export-btn' name='new-prio' value='New Priority' id='new-prio'><i id='new-fa' class='fa fa-file' aria-hidden='true'></i></i>";
    
//    echo "<div class='tooltip-container'>";
    echo "<button class='button btn-logic export-btn' id='export-report' name='export_report'>Export Report</button><i id='export-fa' class='fa fa-file-word-o' aria-hidden='true'></i>";
//    echo "<span class='tooltiptext arrow-left' style='left: 116px;top: -5px;'>Not available in beta version</span>";
//    echo "</div>";

    echo "<button class='button btn-logic hide export-btn' id='word-btn' onclick='return "
            . "logic2docx({ wd_id: \"export\", parent_id: \"tool\", filename: \"OnlineWord.docx\" });'>"
            . "Export Report<i class='fa fa-file-image-o' aria-hidden='true'></i></button>";
    echo "</div>";
    
    include "php-src/forms/logic_tool.php";
    
    $user_id = 1;
    $prio_saved = 0;
    $form_changed = 0;
    
    if($_SERVER["REQUEST_METHOD"] != "POST") {
        load_prio($conn,$user_id);
    }
    
    echo "<input type='text' class='hide' name='prio-saved' id='prio-saved' value='$prio_saved'/>";
    echo "<input type='text' class='hide' name='form-changed' id='form-changed' value='$form_changed'/>";
    
    echo "<input type='text' class='hide' name='tot_uni' id='tot_uni' value='$img_data'/>";
    
    echo "<input type='text' class='hide' name='eu_prio'/>";
    echo "<input type='text' class='hide' name='obj'/>";
    echo "<input type='text' class='hide' name='prio'/>";
    
    include "php-src/handler/post_events.php";
    
 ?>