<?php

if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['export_report'])) {
    
    define('UPLOAD_DIR', 'files/');
    
    $name = 'test.png';
    $img_data = $_POST['tot_uni'];
    $file = UPLOAD_DIR . $name;

    $img = str_replace('data:image/png;base64,', '', $img_data);
    $data = base64_decode($img);
    $success = file_put_contents($file, $data);

    if ($success) {
        $src = 'http://localhost/interlogic/files/' . $name;
        echo "<div class='report-template' id='report-template'>";
        echo "<img src='$src' height='296' width='550'>";
        echo "</div>";
    }
    
    ?>    
        <script type="text/javascript">
            $("#report-template").wordExport();
        </script>

    <?php
}