
<?php 


$description = null;
if($prio) {
    $description = exec_select($conn, "SELECT descr_text FROM prio_descr WHERE up_id = $prio");
}

?>

<fieldset class='logic-description'>
<div class="info-div"><i class="fa fa-info" aria-hidden="true"></i></div>
<div class='notes hide'>
    <p class='notes-title'>Intervention Logic Description</p>

    <i class='fa fa-times' aria-hidden='true'></i>

    <p class='notes-body'>
        These questions will guide you, in order to better describe the 
        rationale behind the structure of the above intervention logic model.
    </p>
</div>

<legend>Intervention Logic Description</legend>
<fieldset>
<input id="item-1" class="toggle-item" checked="" type="checkbox">
<label for='item-1'><span class='decimal'>1</span> 
<span class='text'>How is the context of your region related to the specific Investment Priority?</span>
</label>
<div class='accordion-section'>
<textarea rows="10" cols="101" type="text" name="quest_1"><?php if(count($description)>0) { echo $description[0]['descr_text'];} ?></textarea>
</div>
</fieldset>

<fieldset>
<input id="item-2" class="toggle-item" type="checkbox">
<label for='item-2'><span class='decimal'>2</span> 
<span class='text'>In which ways the shared vision is related to the described regional context?</span>
</label>
<div class='accordion-section'>
<textarea rows="10" cols="101" type="text" name="quest_2"><?php if(count($description)>0) { echo $description[1]['descr_text'];} ?></textarea>
</div>
</fieldset>

<fieldset>
<input id="item-3" class="toggle-item" type="checkbox">
<label for='item-3'><span class='decimal'>3</span> 
<span class='text'>Please, describe the interconnection between the specified priorities and the shared regional vision.</span>
</label>
<div class='accordion-section'>
<textarea rows="10" cols="101" type="text" name="quest_3"><?php if(count($description)>0) { echo $description[2]['descr_text'];} ?></textarea>
</div>
</fieldset>

<fieldset>
<input id="item-4" class="toggle-item" type="checkbox">
<label for='item-4'><span class='decimal'>4</span> 
<span class='text'>In which ways the selected actions contribute to the 
accomplishment of the reginal priorities, related to this Investment Priority?</span>
</label>
<div class='accordion-section'>
<textarea rows="10" cols="101" type="text" name="quest_4"><?php if(count($description)>0) { echo $description[3]['descr_text'];} ?></textarea>
</div>
</fieldset>

<fieldset>
<input id="item-5" class="toggle-item" type="checkbox">
<label for='item-5'><span class='decimal'>5</span> 
<span class='text'>Please, give a short description of the policy mix related to the specific Investment Priority.</span>
</label>
<div class='accordion-section'>
<textarea rows="10" cols="101" type="text" name="quest_5"><?php if(count($description)>0) { echo $description[4]['descr_text'];} ?></textarea>
</div>
</fieldset>

<fieldset>
<input id="item-6" class="toggle-item" type="checkbox">
<label for='item-6'><span class='decimal'>6</span> 
<span class='text'>Please, describe the rationale for choosing the specific result indicators, 
	as well as the ways in which they are related to shared vision and priorities.</span>
</label>
<div class='accordion-section'>
<textarea rows="10" cols="101" type="text" name="quest_6"><?php if(count($description)>0) { echo $description[5]['descr_text'];} ?></textarea>
</div>
</fieldset>

<fieldset>
<input id="item-7" class="toggle-item" type="checkbox">
<label label for='item-7'><span class='decimal'>7</span>
<span class='text'>Please, describe the rationale for choosing the specific output indicators, 
as well as the ways in which they are related to result indicators.</span>
</label>
<div class='accordion-section'>
<textarea rows="10" cols="101" type="text" name="quest_7"><?php if(count($description)>0) { echo $description[6]['descr_text'];} ?></textarea>
</div>
</fieldset>

</fieldset>