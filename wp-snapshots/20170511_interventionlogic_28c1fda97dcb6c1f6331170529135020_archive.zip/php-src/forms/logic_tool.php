<?php

function load_prio($conn,$user_id=null,$prio=null) {
    
    include "filters.php";
    
    echo "<fieldset class='logic-template' id='logic-contents'>";

    echo "<legend>Priority Contents</legend>";

    include "boxes.php";
    echo "<div class='img-div'>";
    echo "<button class='button btn-logic export-btn export-btn' onclick='return "
            . "exportElem2png({ div_id: \"export\", filename: \"OnlineImage.png\" });'>"
            . "Download Image <i class='fa fa-file-image-o' aria-hidden='true'></i></button>";
    echo "</div>";
    include "php-src/templates/export_template.php";
    echo "</fieldset>";

    include "description.php";
}

