
<div class="tab">
    <div class="tablinks btn" id="defaultOpen">
        <input value="Axis-1" id="axis-1" type="text" readonly/>
    </div>
    
    <div class="tablinks btn">
        <input value="Axis-2" id="axis-2" type="text" readonly/>
    </div>
    
    <div class="tablinks btn" id="axis-new" type="text" onclick="openTab(event, 'new')">
        <div class="tab-new">
            <i class="fa fa-plus" aria-hidden="true"></i>
        </div>
    </div>
  </div>
</div>
